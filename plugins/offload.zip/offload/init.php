<?php

/* Load all the related plugin files */
require_once \Altum\Plugin::get('offload')->path . 'Offload.php';
require_once \Altum\Plugin::get('offload')->path . 'aws/aws-autoloader.php';
