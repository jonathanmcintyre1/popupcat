<?php defined('ALTUMCODE') || die() ?>

<?php ob_start() ?>